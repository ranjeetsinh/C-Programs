/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    float r,Volume;
    printf("Enter radius of the spehere(in cm): ");
    scanf("%f",&r);
    Volume=4*3.14*r*r*r/3;
    printf("Volume of the Sphere is: %0.2f cubic cm",Volume);
    return 0;
}
